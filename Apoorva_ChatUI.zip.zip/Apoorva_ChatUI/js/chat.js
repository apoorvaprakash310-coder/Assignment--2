const chatBox = document.getElementById("chatBox");
const input = document.getElementById("userInput");
const sendBtn = document.getElementById("sendBtn");
const welcome = document.getElementById("welcome");

// add message
function addMessage(text, type) {
    let msg = document.createElement("div");
    msg.className = "message " + type;
    msg.innerText = text;
    chatBox.appendChild(msg);
    chatBox.scrollTop = chatBox.scrollHeight;
}

// bot reply (FIXED + HUMAN)
function botReply(text) {

    let msg = text.toLowerCase();
    let reply = "";

    // greetings
    if (msg === "hi" || msg === "hello") {
        reply = "Hello! How are you? How can I help you today?";
    }
    else if (msg.includes("how are you")) {
        reply = "I am doing great! How can I assist you today?";
    }

    // features
    else if (msg.includes("explain")) {
        reply = "A concept is explained in simple and easy way to understand.";
    }
    else if (msg.includes("code")) {
        reply = "Here is simple Python code:\nprint('Hello World')";
    }
    else if (msg.includes("project")) {
        reply = "1. Chatbot project\n2. To-do list app";
    }
    else if (msg.includes("career")) {
        reply = "Choose a career based on your interest and skills.";
    }
    else if (msg.includes("travel")) {
        reply = "Travel helps you explore and relax your mind.";
    }

    else {
        reply = "I am here to help. Ask me anything!";
    }

    setTimeout(() => {
        addMessage(reply, "bot");
    }, 500);
}

// send message
function sendMessage() {
    let text = input.value.trim();
    if (text === "") return;

    welcome.style.display = "none";

    addMessage(text, "user");
    botReply(text);

    input.value = "";
}

// click
sendBtn.onclick = sendMessage;

// enter key FIX
input.addEventListener("keydown", function(e) {
    if (e.key === "Enter") {
        sendMessage();
    }
});

// suggestion click
function selectSuggestion(text) {
    input.value = text;
    sendMessage();
}