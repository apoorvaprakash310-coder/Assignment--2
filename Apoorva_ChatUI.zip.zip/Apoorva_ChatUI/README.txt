ChatUI assignment

Name: Apoorva V P

This project is a simple chatbot user interface similar to ChatGPT. 
I created it using HTML, CSS, and JavaScript as part of my internship assignment.

In this project, users can type messages and get automatic replies from a basic AI logic. 
It also includes features like typing effect, clear chat option, and a clean user interface.

Features:
- User can send messages easily
- AI gives automatic replies
- Typing indicator is shown while replying
- Clear Chat / New Chat option is available
- Works on mobile, tablet, and desktop screens

How to Run:
1. Download or extract the project folder
2. Open the folder in VS Code
3. Right-click on index.html
4. Select "Open with Google Crome"
5. The project will open in your browser

Project Files:
- index.html → main page structure
- style.css → design and layout
- chat.js → functionality and logic
- screenshots → images of UI in different devices

conclsion
This assignment helped me understand frontend development by using HTML, CSS, and JavaScript to build a chatbot.
It also enhanced my creativity and understanding of how to make applications responsive and user-friendly.